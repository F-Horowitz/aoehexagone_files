<?php
/*
Funkumo Horowitz
Page voir_tutoriel.php

La page servant à regarder les tutoriaux.
--------------------------*/

	include ('includes/haut.php');
	include_once('../motor/connexion_sql.php');
	
			if (isset($_GET['id']))
			{
				if (!empty($_GET['id']))
				{
					$req = $bdd->prepare('SELECT * FROM tb_tutoriaux WHERE tuto_id = :id') or die(print_r($bdd->errorInfo()));
					$req->execute(array(':id' => $_GET['id']));
					$donnees = $req->fetch(); ?>
				   
				<section>
				   <p><h2><?php echo $donnees['tuto_titre']; ?></h2></p>
					  <p>
						<?php echo $donnees['tuto_contenu']; ?>
					</p>
				</section>
				
			   <?php
				}
				else
				{
					erreur(ERR_ID_ERRONE);
				}
			}
			else
			{
				erreur(ERR_ID_ERRONE);
			}?>
		
	<?php include ('includes/footer.php'); ?>