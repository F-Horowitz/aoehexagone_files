<!---
Funkumo Horowitz
Page verif_inscription.php

page où on vérifie si le code envoyé par mail est bon et est accroché à un membre. J'ai tout fait moi-même.
--->

	<?php include ('includes/haut.php');
		include_once('../motor/connexion_sql.php'); // Connexion à SQL grâce à une simple inclusion 
		
		if (isset($_GET['code'])) //si la variable POST "code" existe..
		{
			if (!empty($_GET['code'])) //on vérifie juste qu'elle n'est pas vide..
			{
			  /// 1) on vérifie que le code existe réellement et n'a pas déjà été confirmé / "COUNT" fera renvoyer à la requête le nombre d'entrées correspondantes
				$apprendreACompter = $bdd->prepare('SELECT COUNT(*) as nombre_codes WHERE membre_code = :code AND membre_verif = 0') or die(print_r($bdd->errorInfo()));
				$apprendreACompter = $bdd->execute(array($_GET['code']));
				
				$nbCodes = $apprendreACompter->fetch(); // variable qui contient le nombre de codes identiques à la valeur spécifiée
				$idMembre = ; // id du membre
				
				if ($nbCodes == 1) //si la variable est égale à 1, il n'y a qu'un seul code correspondant
				{
				  /// 2) on envoie une requête pour mettre à jour le champ membre_verif spécifié
					$req = $bdd->prepare('UPDATE forum_membres SET membre_verif = 1 WHERE membre_code = :code') or die(print_r($bdd->errorInfo()));
					$req = $bdd->execute(array($_GET['code']));
						$req->closeCursor(); //on ferme le curseur pour cette requête vu qu'elle est terminée
				
				  /// 3) on imprime le message de confirmation sur la page du site
				  $paragraphe_data = $bdd->query('SELECT * FROM paragraphes WHERE id = 5') or die(print_r($bdd->errorInfo()));
				  
					echo('<section>
						  <p><h3>' . nl2br($paragraphe_data['titre']) . '</h3></p>
							<p>' . nl2br($paragraphe_data['contenu']) . '</p>
					</section>');
				}
				else //si dans le cas contraire il n'est pas égal à 1, on vérifie les erreurs
				{
					if ($nbCodes < 1) //le code n'existe pas, car la variable est à zéro !
					{
						echo('<em>ERREUR:</em> le code spécifié n\'existe pas.');
					}
					else if ($nbCodes > 1) //y a plus d'un code correpondant au code spécifié, et donc il n'est pas unique!
					{
						echo('<em>ERREUR interne:</em> le code spécifié existe en plusieurs exemplaires. Merci de faire appel à l\'administrateur.');
					}
				}
			}
			else
			{
				echo('<em>ERREUR:</em> aucun code de confirmation n\'est entré dans la page.');
			}
				
				include ('includes/footer.php'); ?>