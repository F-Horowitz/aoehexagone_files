<?php
/*
Funkumo Horowitz
Page inscription.php

Page d'inscription au site.
--------------------------
*/
	include ('includes/haut.php');
	include_once('../motor/connexion_sql.php'); // Connexion à SQL grâce à une simple inclusion
	?>	
			
	<section>	
	<!--- Section PHP - traitement des données -->
	<?php
		if (!isset($_GET['submit'])) ///Variable $_GET "submit" non existant, on est là pour le formulaire
		{
			echo('<p><h2>Inscription à Age of Empires Hexagone</h2>
			<p>Vous voulez rejoindre la communauté du site ? Vous êtes sur la bonne page.</p>'); //petite phrase d'introduction
			
			echo('<em style="font-size:0.8em;"><strong>*</strong> les informations précédées d\'un astérisque sont obligatoires pour l\'inscription.</em>
					<p><form method="post" action="inscription.php?submit" enctype="multipart/form-data"> <!-- Site -->
					<fieldset>
						<legend>Informations principales</legend>
						<label for="pseudo"><strong>*</strong>Pseudo :</label> <input type="text" name="pseudo" id="pseudo" autofocus required /><br/>
						<label for="motdepasse"><strong>*</strong>Mot de passe :</label> <input type="password" name="motdepasse" id="motdepasse" required /><br/>
						<label for="retaper_motdepasse"><strong>*</strong>Retapez votre mot de passe :</label> <input type="password" name="retaper_motdepasse" id="retaper_motdepasse" required /><br/>
						<label for="email"><strong>*</strong>E-mail :</label> <input type="email" name="email" id="email" required /><br/>
						<label for="localisation">Localisation :</label> <input type="text" name="localisation" id="localisation" /><br/>
					</fieldset></p>
					
					<p><fieldset><legend>Moyens de contacts</legend>
						<label for="msn">Votre adresse Skype:</label> <input type="text"
						name="msn" id="msn" /><br />
						<label for="website">Votre site web :</label> <input type="text"
						name="website" id="website" />
					</fieldset></p>
					
					<p><fieldset> <!-- Forum -->
						<legend>Profil sur le forum</legend>
						<p><label>Avatar :<br/>
						(extensions autorisées : <em style="font-size: 0.7em;">png, jpeg, gif</em>)</label><br/>
							<!-- Avatar -->
						<input type="file" name="avatar" /></p>
						
						<p><label for="signature">Signature :<br/>
						<em style="font-size: 0.7em;">(au cas où vous auriez envie d\'afficher une signature à la fin de votre message)</em></label><br/>
						<textarea type="text" name="signature" id="signature" rows="10" cols="50" />Insérez votre message ici..</textarea><br/>
					</fieldset></p>
					<div style="padding:5px;"><input type="submit" id="submit" value="S\'inscrire" /> <input type="reset" value="Réinitialiser" /></div>
					</form>');
	
		} // Fin du formulaire
		else
			//Vu qu'il existe une variable $_POST "submit", nous sommes dans le cas du traitement.
		{    /*###############################################################################################################*/
			/*################################# ATTENTION: SCRIPT DE TRAITEMENT DU MEMBRE ! #################################*/
		   /*######################################## POUR INSCRIPTION DE CE DERNIER ######################################*/
		   
				//Si les variables POST capitales pour l'inscription existent
			if (isset($_POST['pseudo']) && isset($_POST['motdepasse']) && isset($_POST['retaper_motdepasse']) && isset($_POST['email']))
			{
				$pseudo_erreur1 = NULL;
				$pseudo_erreur2 = NULL;
				$mdp_erreur = NULL;
				$email_erreur1 = NULL;
				$email_erreur2 = NULL;
				$email_erreur3 = NULL;
				$skype_erreur = NULL;
				$signature_erreur = NULL;
				$avatar_erreur = NULL;
				$avatar_erreur1 = NULL;
				$avatar_erreur2 = NULL;
				$avatar_erreur3 = NULL;
				
			//Crucial: On récupère les variables $POST et on les transforme en simples variables
				$i = 0; //variable pour détecter le nombre d'erreurs
				$temps = time();
				$pseudo = htmlspecialchars($_POST['pseudo']);
				$mot_de_passe = sha1(htmlspecialchars($_POST['motdepasse']));
				$retaper_motdepasse = sha1(htmlspecialchars($_POST['retaper_motdepasse']));
				$signature = htmlspecialchars($_POST['signature']);
				$email = htmlspecialchars($_POST['email']);
				$skype = htmlspecialchars($_POST['skype']);
				$website = htmlspecialchars($_POST['website']);
				$localisation = htmlspecialchars($_POST['localisation']);
				
			//Vérification du pseudo (on regarde si il n'est pas déjà existant)..
				$query = $bdd->prepare('SELECT COUNT(*) AS nbr FROM tb_membres WHERE membre_pseudo = :pseudo');
				$query->execute(array('pseudo' => $pseudo));
				
				$pseudo_libre = ($query->fetchColumn()==0)?1:0;
				$query->CloseCursor();
				
				///Cas d'erreur : si..
				
				if(!$pseudo_libre) //... le pseudo n'est pas libre
				{
					$pseudo_erreur1 = "<i>Erreur:</i> votre pseudo est déjà utilisé par un membre.<br/>";
					$i++;
				}
				if (strlen($pseudo) < 3 || strlen($pseudo) > 25) ///... il est trop long
				{
					$pseudo_erreur2 = "<i>Erreur:</i> votre pseudo est soit trop grand, soit trop petit.<br/>";
					$i++;
				}
				// Vérification du mot de passe
				if ($mot_de_passe != $retaper_motdepasse || empty($retaper_motdepasse) || empty($mot_de_passe)) // ... le mot de passe et son double sont différents ou vides
				{
					$mdp_erreur = "<i>Erreur:</i> vos deux mots de passe à taper sont différents, ou alors un des champs est vide.<br/>
					Il vous faut inscrire deux fois votre mot de passe pour confirmer l'inscription.<br/>";
					$i++;
				}
				
			///Vérification de l'adresse e-mail
			
				//Il faut que l'adresse e-mail n'ait jamais été utilisée
				$query=$bdd->prepare('SELECT COUNT(*) AS nbr FROM tb_membres WHERE membre_email = :mail');
				$query->execute(array(':mail' => $email));
				
				$mail_libre = ($query->fetchColumn()== 0) ? 1:0; //On regarde si le mail est libre
				$query->CloseCursor();
				
				if(!$mail_libre)
				{
					$email_erreur1 = "<i>Erreur:</i> Votre adresse email est déjà utilisée par un membre.<br/>";
					$i++;
				}
				//On vérifie la forme maintenant
				/*
				if (!preg_match("#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$", $email))
				{
					$email_erreur2 = "<i>Erreur:</i> Votre adresse e-mail n'a pas un format valide.<br/>";
					$i++;
				}*/
				if (empty($email))
				{
					$email_erreur3 = "<i>Erreur:</i> Vous n'avez pas complété le champ d'adresse e-mail.<br/>Il est obligatoire de donner une adresse mail pour s'inscrire, sinon il n'y a pas de moyen de contact possible.";
					$i++;
				}
				
				//Vérification de l'adresse MSN
				if (!preg_match("#^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]{2,}\.[az]{2,4}$#", $skype) && !empty($skype))
				{
					$skype_erreur = "<i>Erreur:</i> Votre adresse Skype n'a pas un format valide.<br/>";
					$i++;
				}
				//Vérification de la signature
				if (strlen($signature) > 255)
				{
					$signature_erreur = "<i>Erreur:</i> Votre signature est trop longue pour être prise en charge.<br/>
					Veuillez ne pas dépasser les 255 caractères.<br/>";
					$i++;
				}
				
			include_once('../motor/envoi_avatar.php');
				
				if ($i == 0)
				{
					//La ligne suivante sera commentée plus bas
					$nomavatar = (!empty($_FILES['avatar']['size']))?move_avatar($_FILES['avatar']):'';
							
						$query = $bdd->prepare('INSERT INTO tb_membres (membre_pseudo,	membre_mdp, membre_email,
						membre_msn, membre_siteweb, membre_avatar, membre_signature, membre_localisation, membre_inscrit,
						membre_derniere_visite) VALUES (:pseudo, :pass, :email, :skype, :website, :nomavatar, :signature, :localisation, :temps, :temps)');
						$inscription_accomplie = $query->execute(array(
						'pseudo' => $pseudo,
						'pass' => $mot_de_passe,
						'email' => $email,
						'skype' => $skype,
						'website' => $website,
						'nomavatar' => $nomavatar,
						'signature' => $signature,
						'localisation' => $localisation,
						'temps' => $temps));
						
						if ($inscription_accomplie)
						{
							echo('<h2>Inscription terminée</h2>');
							echo('<p>Bienvenue <i>'.stripslashes(htmlspecialchars($_POST['pseudo'])).'</i> !<br/>
							Vous êtes maintenant inscrit sur le site d\'Age of Empires Hexagone ; vous êtes désormais un membre de la communauté francophone ! :)<br/>
							Maintenant que vous faites partie du site, vous pouvez accéder à votre propre messagerie privée, accéder aux trois forums du site ou même personnaliser votre profil. Si jamais vous ne savez pas par où commencer ou que vous êtes débutant dans le jeu, je vous propose
							d\'accéder aux articles et tutoriaux sur le jeu, ou de suivre la campagne d\'apprentissage. Vous êtes en tout cas le bienvenue ici !</p>
							<p style="text-align: right;"><i>- Horowitz,<span style="font-size:0.87em;"> fondateur du site AoE Universe</span></i></p>
							<p style="text-align: center;"><b>Cliquez <a href="./index.php">ici</a></b> pour revenir à la page d accueil.</p>
							<p></p>
							<span class="separator"></span>');
						
						//Et on définit les variables de sessions
							$_SESSION['pseudo'] = $pseudo;
							$_SESSION['id'] = $bdd->lastInsertId();
							$_SESSION['rang'] = 2;					
						
							///Envoi d'un mail au compte du joueur
						//Titre
							$titre = "Bienvenue sur Age of Empires Hexagone (confirm.)";
						//Message
							$message = "Cher " . $pseudo . ",<br/>
							Votre identité a été bien confirmée puisque vous avez validé votre inscription via votre compte-mail.<br/>
							Ou alors dans un autre cas, c'est un autre individu qui ne s'est pas gêné pour pirater votre compte et valider son inscription,
							mais dans ce cas je crois qu'il aurait décidé de faire autre chose que valider ce compte comme par exemple vous voler des données
							personnelles par vot-ENFIN BREF!<br/>
							
							Vous êtes désormais inscrit officiellement dans la communauté d'Age of Empires Hexagone avec le mot de passe <b>" . $mot_de_passe . "</b>.
							<em>Retenez bien ce mot de passe et gardez ce mail précieusement</em> car si jamais vous l'oubliez, vous n'aurez plus accès à votre compte et vous devrez passer par un certain
							processus de sécurité pour le récupérer.
							
							Par cela, vous avez donc abilité à accéder au forum et à faire connaissance avec les autres joueurs, ainsi qu'aux autres fonctions dédiées aux<br/>
							membres. Je vous souhaite une bonne navigation sur le site !<br/>
										- Funkumo Horowitz (<em>fondateur du site communautaire</em>)";
							
							mail($_POST['email'], $titre, $message);
								
								$query->CloseCursor();
						}
						else
						{
							erreur(ERR_SQL);
						}
				}
					else
					{
						echo '<p><h2>Inscription interrompue</h2>';
						echo '<p class="error"><span id="error_nb_erreurs">'.$i.' erreur(s)</span><br/><br/>';
						echo '<span id="error_subtitle">Une ou plusieurs erreurs se sont produites pendant l\'inscription.</span><br/>';
						echo ''. $pseudo_erreur1 . '<br/>';
						echo $pseudo_erreur2;
						echo $mdp_erreur;
						echo $email_erreur1;
						echo $email_erreur2;
						echo $email_erreur3;
						echo $msn_erreur;
						echo $signature_erreur;
						echo $avatar_erreur;
						echo $avatar_erreur1;
						echo $avatar_erreur2;
						echo $avatar_erreur3;
						echo '<br/>Cliquez <a href="inscription.php">ici</a> pour recommencer.</p>';
					}
			}
			else
			{
				echo('<p class="error"><strong>Erreur:</strong> Les champs n\'ont pas tous été renseignés.</p>');
			}
			
			/*###############################################################################################################*/
			/*################################# FIN DU SCRIPT DE TRAITEMENT D'INSCRIPTION ##################################*/
		   /*######################################## DU MEMBRE A LA BASE DE DONNEES ######################################*/
			
		}
		?>
		</section>
		<?php include ('includes/footer.php'); ?>
</body>
</html>