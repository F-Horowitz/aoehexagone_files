<!---
Funkumo Horowitz
Page connexion.php

Permet la connexion au site, si le joueur est inscrit évidemment.
--->

	<?php include ('includes/haut.php');
		include_once('../motor/connexion_sql.php'); // Connexion à SQL grâce à une simple inclusion

	if (!isset($_GET['deconnexion'])) //si il n'existe pas de variable GET "deconnexion"
	{
		if ($connecte) erreur(ERR_IS_CO); // Si il est connecté, la page affiche une erreur

			if (!isset($_POST['pseudo']) AND !isset($_POST['pass'])) //Si les variables POST "pseudo" et "pass" n'existent pas...
			{
			echo('<section><p><h2>Se connecter</h2></p>
			  <p style="font-style: italic; margin-bottom: 3px;">Veuillez renseigner vos identifiants pour pouvoir vous connecter à votre compte.</p>
			  
			  <form method="post" action="connexion.php">
				<p><label for="pseudo">Pseudo :</label> <input type="text" name="pseudo" id="pseudo" /><br/>
				<label for="pass">Mot de passe :</label> <input type="password" name="pass" id="pass" /></p>
				<p><label for="connexion_auto">Connexion automatique</label> <input type="checkbox" name="connexion_auto" id="connexion_auto"/></p>
				<input type="hidden" name="page" value=" '. $_SERVER['HTTP_REFERER'] .'" />
				<input type="submit" value="Envoyer" />
			</form>');					
			}
			else //sinon, cela veut dire que la page est censée confirmer une connexion
			{
				$page = htmlspecialchars($_POST['page']);
				
				if (empty($_POST['pseudo']) || empty($_POST['pass'])) //regardons si un champ est oublié
				{
					echo('<p class="error">Vous devez entrer votre pseudonyme et votre mot de passe pour pouvoir vous connecter.</p>'); //si oui
				}
				else //si aucun champ n'est vide, on vérifie le mot de passe...
				{
					$query = $bdd->prepare('SELECT membre_pseudo, membre_mdp, membre_id, membre_rang FROM tb_membres WHERE membre_pseudo = :pseudo');
					/* Normalement la BDD devrait trouver une entrée correspondant au pseudo. Mais si jamais il n'en existe pas... ben voilà quoi. */
					$query->execute(array('pseudo' => $_POST['pseudo']));
					$data = $query->fetch();
					
						if ($data['membre_mdp'] == sha1($_POST['pass']))  //Le mot de passe correspond à celui de la DB?
						{
							$_SESSION['pseudo'] = $data['membre_pseudo'];
							$_SESSION['rang'] = $data['membre_rang'];
							$_SESSION['id'] = $data['membre_id'];
							
							if (isset($_POST['connexion_auto']))
								{
								$expire = time() + 365*24*3600;
								setcookie('pseudo', $_SESSION['pseudo'], $expire); //On insère de nouveaux cookies tiré de la BDD
								setcookie('mdp', $_SESSION['pass'], $expire);
								}

							echo('<p>Bienvenue ' . $data['membre_pseudo'] . ', vous êtes maintenant connecté!<br/>
							Cliquez <a href=" ' .$page . ' ">ici</a> pour revenir à la page précédente.</p>');
							}
						}
						else // Une grosse erreur fatale du feu de l'enfer, un des deux identifiants n'est pas correct.
						{
							echo('<p class="error">Un des deux identifiants entrés n\'est pas correct.</p>
							<p>Cliquez <a href="http://ageofempires-hexagone.fr/site/index.php">ici</a> pour revenir à la page d\'accueil.<br />
							<br />Cliquez <a href=" ' .$page . ' ">ici</a> pour revenir à la page précédente.</p>');
						}
					
					$query->CloseCursor();
				}
			}
	}
	else //si autrement, on est là pour déconnecter le membre
	{
		if (empty($_GET['deconnexion'])) //si la variable GET n'est pas vide
		{
			/* Funkumo Horowitz
			Page deconnexion.php
			Déconnecte le visiteur du site et détruit sa session. */
			
			session_start(); //on recrée la session.. (une sorte d'actualisation)

			if (isset($_COOKIE['pseudo']) && isset($_COOKIE['mdp']))
			{
				setcookie('pseudo', '', -1);
				setcookie('mdp', '', -1);
			}

			session_destroy(); // ..pour la détruire ensuite!

			if ($id == 0) { erreur(ERR_IS_NOT_CO); } //la variable id est égale à 0, le visiteur n'est pas connecté
			else {
					echo '<p>Vous êtes à présent déconnecté.<br />
					Cliquez <a href=" ' . htmlspecialchars($_SERVER['HTTP_REFERER']) . '">ici</a> pour revenir à la page précédente.<br /></p>';
					echo '</div></body></html>';
					Location: ('index.php'); //on redirige vers la page d'accueil principale du site 
				}
		}
		else //autrement BEP!
		{
			erreur(ERR_URL_INCORRECT);
		}
	}
			?>
			
		</section>
		
	<?php include ('includes/footer.php'); ?>