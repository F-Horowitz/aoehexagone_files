<!---------
Funkumo Horowitz
Page indispensables.php

La page des essentiels remaniée, renommée "Grenier".





...






cela vous plaît de fouiller dans le code HTML des sites internet comme ça? Faire ça, c'est un peu comme regarder sous la jupe d'une fille, on
sait pas toujours ce qu'on y trouvera.
-------------------------->

	<?php include ('includes/haut.php');
		include_once('../motor/connexion_sql.php'); // Connexion à SQL grâce à une simple inclusion
			$req = $bdd->query('SELECT titre, contenu FROM tb_paragraphs WHERE id = 1') or die(print_r($bdd->errorInfo()));
			$paragraphe = $req->fetch(); ?>
			
	<section><h2><?php echo nl2br($paragraphe['titre']); ?></h2>
			  <p><?php echo nl2br($paragraphe['contenu']);?></p>
			  

	</section>
	
	<?php include ('includes/footer.php'); ?>