<!--- cadre_membre.php : include contenant le cadre profil du membre.
Age of Empires Hexagone --->

<?php
	if ($connecte)
	{
		echo('<div class="ligne_membre"><img src="www.ageofempires-hexagone.fr/images/avatars/' . $_SESSION['membre_id'] . '.png" class="avatar" /> */ Bonjour, '. $_SESSION['membre_pseudo'] .' !<br/>
		<span style="font-size:0.9em;"><a title="Profil" href="http://ageofempires-hexagone.fr/site/profil.php">Votre profil</a> - <a title="Déconnexion" href="http://ageofempires-hexagone.fr/site/connexion.php">Déconnexion</a></span></div>');
	}
	else
	{
		echo('<div class="ligne_membre">Bienvenue, visiteur !
		<span style="font-size:0.9em;"><a title="Connexion" href="http://ageofempires-hexagone.fr/site/connexion.php">Se connecter</a> - <a title="Inscription" href="http://ageofempires-hexagone.fr/site/inscription.php">S\'inscrire</a></span></div>');
	}
?>