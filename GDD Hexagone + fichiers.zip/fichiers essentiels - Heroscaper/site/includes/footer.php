<?php
/*
Funkumo Horowitz
Page footer.php

Pied de page. Contient mon copyright et les remerciements.
*/
?>		</div><footer>
			<div class="footer_float_left"> <!-- Copyright -->
			<p><?php echo $nom_site; ?> © Age of Empires Hexagone, 2013-2016. Tous les droits sur le site et son architecture HTML reviennent à son créateur.
			Je remercie grandement les personnes qui m'ont soutenu dans la réalisation longue et ardue de ce projet. Merci grandement !<br/><br/>
			Age of Empires appartient <span style="font-size: 0.7em;">(malheureusement!)</span> à <em>Microsoft Game Studios Inc.</em> et le mérite de son développement à <em>Ensemble Studios.</em>
			 </div>
			
			<p>Si jamais vous rencontrez un problème technique ou voulez nous signaler un bug, n'hésitez pas et <a href="./contact.php">contactez-nous!</a></p>
			
			<div class="footer_float_right"> <!-- Liens vers les forums disponibles -->
				<h3>Accéder au forum..</h3>
				<ul>
					<li><a href="http://ageofempires-hexagone.fr/forums/forum_aoe/">Age of Empires</a></li>
					<li><a href="http://ageofempires-hexagone.fr/forums/forum_aoe2/">Age of Empires II</a></li>
					<li><a href="http://ageofempires-hexagone.fr/forums/forum_aoe3/">Age of Empires III</a></li>
					<li><a href="http://www.jeuxvideo.com">jeuxvideo.com</a></li>
				</ul></p>
			</div>
		</footer>
	</body>
</html>