<!--
Funkumo Horowitz
Include : liste des forums du site -->

<aside class="forums">
<p><h4>Liste des forums :</h4>

<a href="../../forums/forum_aoe/">Age of Empires I</a><br/>
<a href="../../forums/forum_aoe2/">Age of Empires II</a><br/>
<a href="../../forums/forum_aoe3/">Age of Empires III</a><br/>
</p>
</aside>