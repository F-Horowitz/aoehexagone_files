﻿<!---
Funkumo Horowitz
Page about.php

Page d'à-propos du site. Montre le pourquoi du comment du site.
--->

	<?php include ('includes/haut.php');
		include_once('../motor/connexion_sql.php'); // Connexion à SQL grâce à une simple inclusion
		
		$req = $bdd->query('SELECT titre, contenu FROM tb_paragraphs WHERE id = 3') or
		die(print_r($bdd->errorInfo()));
			$paragraphe = $req->fetch(); ?>

        <section>
		   <h2><?php echo $paragraphe['titre'] ?></h2>
			  <p><?php echo $paragraphe['contenu'] ?></p>
		</section>

	<?php include ('includes/footer.php'); ?>