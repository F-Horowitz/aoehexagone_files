﻿<!---
Funkumo Horowitz
Page index.php

Véritable page d'accueil, ne sera publiée qu'à la publication du site entier. Elle regroupe la présentation rapide et les news du site.
Ne faites pas confiance aux inconnus.
--->

	<?php include ('includes/haut.php');
		include_once('../motor/connexion_sql.php'); // Connexion à SQL grâce à une simple inclusion
		
		$req = $bdd->query('SELECT titre, contenu FROM tb_paragraphs WHERE id = 0') or die(print_r($bdd->errorInfo()));
		$paragraphe = $req->fetch();
		$req->closeCursor();?>

        <section>
		   <h2 id="titre_page"><?php echo nl2br($paragraphe['titre']); ?></h2>		   
			<p><?php echo nl2br($paragraphe['contenu']); ?></p>

			<aside>
			<h3>L'actualité</h3>
			<table>
			<td>
				<th>Titre</th>
				<th>Auteur</th>
				<th>Date de rédaction</th>
			</td>
			<?php // On récupère les sept dernières news postées
			$req_news = $bdd->query('SELECT * FROM tb_news WHERE news_cacher = 0');
			
			while ($data_news = $req_news->fetch())
			{
				echo('<tl><a href="http://ageofempires-hexagone.fr/site/afficher_news.php?id=' . $data_news['news_id'] . '">'. $data_news['news_titre'] . '</a> postée par ' . $data_news['news_auteur'] . ' le ' . $data_news['news_dateredaction'] . '</tl><br/>');
			}
			?>
			</table>
			</aside>
		</section>

	<?php include ('includes/footer.php'); ?>