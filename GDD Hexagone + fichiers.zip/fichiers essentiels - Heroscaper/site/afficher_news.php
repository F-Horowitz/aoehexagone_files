﻿<?php
/*
Funkumo Horowitz
Page regardernews.php

La page servant à regarder les news, dépendante des paramètres URL. Elle doit être évidemment plus sécurisée, sinon il y a
risque de faille.
--------------------------*/

	include ('includes/haut.php');
	include_once ('../motor/connexion_sql.php'); // Connexion à SQL
	
			if (isset($_GET['id'])) // Si il existe la variable GET "id"
			{
				$req_nombreid = $bdd->query('SELECT COUNT(*) AS nombre_id FROM tb_news');
				$nombre_id = $req_nombreid->fetch();
				
				if ($nombre_id > $_GET['id']) // tentative réussie: si l'identifiant existe, c'est bon, la news est affichée.
				{
				   $req = $bdd->prepare('SELECT * FROM tb_news WHERE news_id = :id') or die(print_r($bdd->errorInfo()));
				   $req->execute(array('id' => $_GET['id']));
				   $donnees = $req->fetch(); ?>
				   
					<section>
					   <p><h2><?php echo $donnees['news_titre']; ?></h2></p>
						  <p>
							<?php echo $donnees['news_contenu']; ?>
						</p>
				</section>
				
			   <?php
				}
				else
				{
					erreur(ERR_ID_ERRONE);
				}
			}
			else
			{
				erreur(ERR_ID_ERRONE);
				$req->closeCursor();
			}?>
		
	<?php include ('includes/footer.php'); ?>