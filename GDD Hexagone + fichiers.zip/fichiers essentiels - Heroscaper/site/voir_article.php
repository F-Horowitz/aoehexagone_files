<?php
/*
Funkumo Horowitz
Page voir_article.php

La page servant à regarder les articles, dépendante des paramètres URL. Elle doit être évidemment plus sécurisée, sinon il y a
risque de faille.
--------------------------*/

	include ('includes/haut.php');
	include_once('../motor/connexion_sql.php');
	
			if (isset($_GET['id']) && !empty($_GET['id']))
			{
				
					$req = $bdd->prepare('SELECT * FROM tb_articles WHERE article_id = :id') or die(print_r($bdd->errorInfo()));
					$req->execute(array('id' => $_GET['id']));
					$donnees = $req->fetch(); ?>
				   
				<section>
				   <p><h2><?php echo $donnees['article_titre']; ?></h2></p>
					  <p>
						<?php echo $donnees['article_contenu']; ?>
					</p>
				</section>
			
			<?php
			}
			else
			{
				erreur(ERR_ID_ERRONE);
			}?>
		
	<?php include ('includes/footer.php'); ?>