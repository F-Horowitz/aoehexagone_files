<!---- Age of Empires Hexagone /// articles_tutos.php
Cette page réunit tous les articles et tutoriaux écrits par nos chers membres, dont principalement ceux
écrits par la rédaction administrative. Normalement, tout contenu de cette section est contrôlé et vérifié
par l'équipe administrative. Oui, c'est à toi que je parle, toi l'enfumé qui regarde le code HTML de cette page.
----->

	<?php include('includes/haut.php');
	include ('../motor/connexion_sql.php');
	$query = $bdd->query('SELECT titre, contenu FROM tb_paragraphs WHERE id = 2');
		  $data = $query->fetch(); ?>
		  
	<section><h2><?php echo $data['titre'] ?></h2>
	<p><?php echo $data['contenu'] ?></p>
		
		<h3>Articles de rédaction</h3>
		<table class="liste">
			<tr>
				<th class="titre_contenu">Titre</th>
				<th class="auteur_contenu">Auteur</th>
				<th class="datecreation_contenu">Date de création</th>
			</tr>
		<?php $query = $bdd->query('SELECT * FROM tb_articles WHERE article_cache = 0');
		while ($data = $query->fetch()){ //on affiche tous les articles disponibles
			echo('<tr><td><strong><a href="http://ageofempires-hexagone.fr/site/voir_article?id=' . $data['article_id'] . '">' . $data['article_titre'] . '</a></strong></td>
			<td><span style="font-size: 0.9em;"> ' . $data['article_auteur'] . ' </span></td>
			<td><em style="font-size: 0.84em;">' . $data['article_datecreation'] . '</em></td></tr>');
		}?>
		</table>
		
		<h3>Tutoriaux</h3>
		<table class="liste">
			<tr>
				<th class="titre_contenu">Titre</th>
				<th class="auteur_contenu">Auteur</th>
				<th class="datecreation_contenu">Date de création</th>
			</tr>
		<?php $query = $bdd->query('SELECT * FROM tb_tutoriaux WHERE tuto_cache = 0');
		while ($data = $query->fetch()){ //on affiche tous les tutoriaux disponibles
			echo('<tr><td><strong><a href="http://ageofempires-hexagone.fr/site/voir_tutoriel?id=' . $data['tuto_id'] . '">' . $data['tuto_titre'] . '</a></strong></td>
			<td><span style="font-size: 0.9em;"> ' . $data['tuto_auteur'] . ' </span></td>
			<td><em style="font-size: 0.84em;">' . $data['tuto_datecreation'] . '</em></td></tr>');
		}?>
		</table>
	</section>
	
	<?php include ('includes/footer.php'); ?>