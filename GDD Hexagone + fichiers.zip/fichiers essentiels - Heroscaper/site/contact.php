﻿<?php
/*
Funkumo
Page contact.php

Page de contact.
--------------------------
*/
	include ('includes/haut.php');
	include_once('../motor/connexion_sql.php'); // Connexion à SQL grâce à une simple inclusion
	
		$req = $bdd->query('SELECT titre, contenu FROM tb_paragraphs WHERE id = 4') or
		die(print_r($bdd->errorInfo()));
			$paragraphe = $req->fetch(); ?>	
			
	<section>
		   <p><h2><?php echo nl2br($paragraphe['titre']); ?></h2></p>
			  <?php
					echo nl2br($paragraphe['contenu']);
			   ?>
            </p>
	</section>
	
	<!--- Section PHP - traitement des données -->
	<?php
		if (isset($_GET['traitement']))// Donc si le paramètre "traitement" existe...
		{ // la condition est vraie et on peut vérifier si tout est renseigné.
			if (!empty($_POST['pseudo']) AND !empty($_POST['objet']) AND !empty($_POST['message']))
			{
				echo('Le message a été envoyé ! Maintenant, il ne manque plus qu\'à créer le système d\'envoi de mail.');
			}
			else
			{
				echo('Erreur : le formulaire de requête est incomplet...');
			}
		}
		else
		{
			echo('Debug : pour le moment, rien n\'est envoyé');
		}?>
	<section class="contact">
		<p><form method="post" action="contact.php?traitement">
			<label for="pseudo">Pseudo :</label> <input type="text" name="pseudo" id="pseudo" /><br/>
			<label for="objet">Sujet de la requête :</label> <input type="text" name="objet" id="objet"/><br/>
			<label for="message">Message :</label><br/><textarea type="text" name="message" id="message" rows="10" cols="50" />Insérez votre message ici..</textarea><br/>
			
			<input type="submit" value="Envoyer" /> <input type="reset" value="Réinitialiser" />
		</form></p>
	</section>
	
			<?php include ('includes/footer.php'); ?>
</body>
</html>