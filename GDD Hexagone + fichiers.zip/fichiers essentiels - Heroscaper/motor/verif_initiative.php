<!---- Age of Empires Universe /// verif_initiative.php

Cette page moteur est plus qu'importante, n'y TOUCHEZ SURTOUT PAS! <--
Elle est incluse dans la page admin de liste des contenus pour vérifier l'initiative du gradé dans ce qu'il veut faire
concernant la chose. Si jamais il y a une erreur dans cette page, les conséquences en seraient fatales pour
le système d'édition entier.

Faites appel, je vous prie, à votre bon sens et ne touchez pas à ce mécanisme.
----->

	 <!--------------------------------------------------------------->
	<!----------------------- DOMAINE DES NEWS ------------------------>
	 <!--------------------------------------------------------------->
	 
<?php
	//-----------------------------------------------------
	// Vérification 1 : est-ce qu'on veut poster ou modifier une news ?
	//-----------------------------------------------------
	if (isset($_POST['titre_news']) AND isset($_POST['contenu_news']))
	{
		$titre = htmlspecialchars($_POST['titre_news']);
		$contenu = htmlspecialchars($_POST['contenu_news']);
		
		// On vérifie si c'est une modification de news ou non...
		if ($_POST['id_news'] == 0)
		{
			// Ce n'est pas une modification, on crée une nouvelle entrée dans la table.
			$bdd->query("INSERT INTO tb_news VALUES('', '" . $titre . "', '" . $contenu . "', '" . time() . "')");
		}
		else
		{
			// On protège la variable "id_news" pour éviter une faille SQL.
			$valeur_modifnews = htmlspecialchars($_POST['id_news']);
			// C'est une modification, on met juste à jour le titre et le contenu.
			$bdd->query("UPDATE tb_news SET news_titre='" . $titre . "', news_contenu='" . $contenu . "' WHERE news_id='" . $valeur_modifnews . "'");
		}
	}
	  
	//--------------------------------------------------------
	// Vérification 2 : est-ce qu'on veut supprimer une news ?
	//--------------------------------------------------------
	if (isset($_GET['supprimer_news'])) // Si l'on demande de supprimer une news..
	{
		//... alors on supprime la news correspondante.
		// On protège la variable « id_news » pour éviter une faille SQL.
		$valeur_supprnews = htmlspecialchars($_GET['supprimer_news']);
		$bdd->query('DELETE FROM tb_news WHERE news_id=\'' . $valeur_supprnews . '\'');
	}
?>
	 <!----------------------------------------------------------------->
	<!----------------------- DOMAINE DES ARTICLES ---------------------->
	 <!----------------------------------------------------------------->
<?php
	//-----------------------------------------------------
	// Vérification 1 : poster un article ?
	//-----------------------------------------------------
	if (isset($_POST['titre_article']) AND isset($_POST['contenu_article']))
	{
		$titre = htmlspecialchars($_POST['titre']);
		$contenu = htmlspecialchars($_POST['contenu']);
		// On vérifie si c'est une modification d'article ou non.
		if ($_POST['id_article'] == 0)
		{
			// Ce n'est pas une modification, on crée une nouvelle entrée dans la table.
			$bdd->query("INSERT INTO tb_articles VALUES('', '" . $titre . "', '" . $contenu . "', '" . time() . "')");
		}
		else
		{
			// On protège la variable "id_news" pour éviter une faille SQL.
			$_POST['id_article'] = htmlspecialchars($_POST['id_article']);
			// C'est une modification, on met juste à jour le titre et le contenu.
			$bdd->query("UPDATE tb_articles SET article_titre='" . $titre . "', contenu='" . $contenu . "' WHERE article_id='" . $_POST['id_article'] . "'");
		}
	}
	  
	//--------------------------------------------------------
	// Vérification 2 : supprimer un article?
	//--------------------------------------------------------
	if (isset($_GET['supprimer_article'])) // Si l'on demande de supprimer une news.
	{
		// Alors on supprime l'article correspondante.
		// On protège la variable « id_article » pour éviter une faille SQL.
		$_GET['supprimer_article'] = htmlspecialchars($_GET['supprimer_article']);
		$bdd->query('DELETE FROM tb_articles WHERE article_id=\'' . $_GET['supprimer_article'] . '\'');
	}
?>

 <!----------------------------------------------------------------->
	<!----------------------- DOMAINE DES TUTORIELS ---------------------->
	 <!----------------------------------------------------------------->
<?php
	//-----------------------------------------------------
	// Vérification 1 : poster un tutoriel ?
	//-----------------------------------------------------
	if (isset($_POST['titre_article']) AND isset($_POST['contenu_article']))
	{
		$titre = htmlspecialchars($_POST['titre']);
		$contenu = htmlspecialchars($_POST['contenu']);
		// On vérifie si c'est une modification d'article ou non.
		if ($_POST['id_article'] == 0)
		{
			// Ce n'est pas une modification, on crée une nouvelle entrée dans la table.
			$bdd->query("INSERT INTO tb_articles VALUES('', '" . $titre . "', '" . $contenu . "', '" . time() . "')");
		}
		else
		{
			// On protège la variable "id_news" pour éviter une faille SQL.
			$_POST['id_article'] = htmlspecialchars($_POST['id_article']);
			// C'est une modification, on met juste à jour le titre et le contenu.
			$bdd->query("UPDATE tb_articles SET article_titre='" . $titre . "', contenu='" . $contenu . "' WHERE article_id='" . $_POST['id_article'] . "'");
		}
	}
	  
	//--------------------------------------------------------
	// Vérification 2 : supprimer un tutoriel?
	//--------------------------------------------------------
	if (isset($_GET['supprimer_tuto'])) // Si l'on demande de supprimer une news.
	{
		// Alors on supprime l'article correspondante.
		// On protège la variable « id_article » pour éviter une faille SQL.
		$_GET['supprimer_article'] = htmlspecialchars($_GET['supprimer_article']);
		$bdd->query('DELETE FROM tb_articles WHERE article_id=\'' . $_GET['supprimer_article'] . '\'');
	}
?>