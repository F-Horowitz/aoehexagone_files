<?php
/*
Funkumo Horowitz
Page constantes.php

Inscrit toutes les constantes du site.
--------------------------
*/
///Gestion des erreurs
define('ERR_IS_CO', 'Vous ne pouvez pas accéder à cette page si vous êtes connecté.');
define('ERR_IS_NOT_CO', 'Vous ne pouvez pas accéder à cette page si vous n\'êtes pas connecté.');
define('ERR_URL_INCORRECT', 'L\'URL est très mal écrite et donc grammaticalement incorrecte.');
define('ERR_WRONG_USER', 'Vous n\'êtes pas autorisé à regarder ce message <strong>privé</strong>!');
define('ERR_SQL', 'Fatale. Erreur SQL détectée, impossible de continuer l\'opération. Merci de contacter Horowitz.');
define('ERR_ID_ERRONE', 'L\'identifiant est incorrect ou inexistant.');

///Simples définitions de constantes
define('VISITEUR',1); // forums
define('MEMBRE',2);
define('MODERATEUR',3);
define('ADMIN',4);

?>