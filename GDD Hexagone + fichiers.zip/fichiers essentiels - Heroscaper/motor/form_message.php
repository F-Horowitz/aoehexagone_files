<!---
Funkumo Horowitz
Page form_message.php

Include contenant le formulaire d'écriture de messages pour toute utilisation avec une balise form. Uniquement en HTML.
--->
				<div class="form_message"><p>
					<text for="titre">Titre : </label>
					<input type="text" size="80" id="titre" name="titre" /><br /><br />
					
					<fieldset id="mise_en_forme"><input type="button" id="gras" name="gras" value="Gras"	onClick="javascript:bbcode('[g]', '[/g]');return(false)" />
					<input type="button" id="italique" name="italique" value="Italique" onClick="javascript:bbcode('[i]', '[/i]');return(false)" />
					<input type="button" id="souligné" name="souligné" value="Souligné" onClick="javascript:bbcode('[s]','[/s]');return(false)" />
					<input type="button" id="lien" name="lien" value="Lien"	onClick="javascript:bbcode('[url]', '[/url]');return(false)" />
					
					<img src="./images/smilies/heureux.png" title="heureux" alt="heureux" onClick="javascript:smilies(':D');return(false)" />
					<img src="../images/smilies/clindoeil_anime.gif" title="clindoeil_anime" alt="clindoeil_anime" onClick="javascript:smilies(':lol:');return(false)" />
					<img src="../images/smilies/clindoeil.png" title="clindoeil" alt="clindoeil" onClick="javascript:smilies(':triste:');return(false)" />
					<img src="../images/smilies/cool.gif" title="cool" alt="cool" onClick="javascript:smilies(':frime:');return(false)" />
					<img src="../images/smilies/rire.gif" title="rire" alt="rire" onClick="javascript:smilies('XD');return(false)" />
					<img src="../images/smilies/confus.gif" title="confus" alt="confus" onClick="javascript:smilies(':s');return(false)" />
					<img src="../images/smilies/choc.gif" title="choc" alt="choc" onClick="javascript:smilies(':O');return(false)" />
					<img src="../images/smilies/question.gif" title="?" alt="?" onClick="javascript:smilies(':interrogation:');return(false)" />
					<img src="../images/smilies/exclamation.gif" title="!" alt="!" onClick="javascript:smilies(':exclamation:');return(false)" />
					<img src="../images/smilies/joker.png" title="joker" alt="joker" onClick="javascript:smilies(':joker:');return(false)" />
					<img src="../images/smilies/afro.png" title="afro" alt="afro" onClick="javascript:smilies(':afro:');return(false)" /><br /></fieldset>
					
					<textarea cols="80" rows="8" id="message" name="message"></textarea>
					<br /></p>
					
					<p>
					<input type="submit" name="submit" value="Envoyer" />
					<input type="reset" name="Effacer" value="Effacer" /></p>
				</div>