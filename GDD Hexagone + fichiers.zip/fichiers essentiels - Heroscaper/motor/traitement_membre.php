<!----
Funkumo Horowitz
Page traitement_membre.php
Fichier moteur : inscrit un membre dans la base de données si les conditions sont vraies
--->

<?php

?>