<?php
/*
Funkumo
Page config.php

Cette page est très importante car elle contient toutes les variables principales
du site et du forum. Ne pas toucher si manque de compréhension.
----------------------------
*/

//SITE
$nom_site = "Age of Empires Universe";
$date_heure;
$mois = 1;

//FORUMS
$lvl = 0;

//AUTRES
$queries = 0;
$connecte = false;1
?>