<!---------
Funkumo Horowitz
Page envoi_avatar.php

Fichier moteur : enregistre avec conditions l'avatar lors de l'inscription
-------------------------->

	<?php include_once('connexion_sql.php'); // Connexion à SQL grâce à une simple inclusion
		// Testons si le fichier a bien été envoyé et s'il n'y a pas d'erreur..
	
			//Vérification de l'avatar :
			if (!empty($_FILES['avatar']['size']))
			{
				//On définit les variables :
				$maxsize = 10024; //Poid de l'image
				$maxwidth = 100; //Largeur de l'image
				$maxheight = 100; //Longueur de l'image
				$extensions_valides = array('jpg' , 'jpeg' , 'gif' , 'png', 'bmp'); //Liste des extensions valides
				
			if ($_FILES['avatar']['error'] > 0) ///erreur indéfinie..
			{
				$avatar_erreur = "Erreur lors du transfert de l'avatar : ";
			}
			
				if ($_FILES['avatar']['size'] > $maxsize) //fichier trop gros
				{
					$i++;
					$avatar_erreur1 = "Le fichier est trop gros : votre fichier fait
					<strong>".$_FILES['avatar']['size']." octets</strong> alors qu'il ne doit pas dépasser les
					<strong>".$maxsize." octets</strong>.";
				}
				$image_sizes = getimagesize($_FILES['avatar']['tmp_name']);
				
				if ($image_sizes[0] > $maxwidth OR $image_sizes[1] > $maxheight) //l'image est trop longue ou large
				{
					$i++;
					$avatar_erreur2 = "L'image est trop large ou trop longue - (<strong>".$image_sizes[0]."x".$image_sizes[1]."</strong> contre <strong>".$maxwidth."x".$maxheight."</strong>)";
				}
				$extension_upload = strtolower(substr(strrchr($_FILES['avatar']['name'], '.') ,1));
				
				if (!in_array($extension_upload,$extensions_valides))
				{
					$i++;
					$avatar_erreur3 = "L'extension de l'image est incorrecte.";
				}
			}
	?>