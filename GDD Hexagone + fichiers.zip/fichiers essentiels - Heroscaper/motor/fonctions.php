<?php
/*
Funkumo Horowitz
Page fonctions.php

Inscrit toutes les fonctions du site.
--------------------------
*/

function erreur($err='')
{
	$mess=($err!='')? $err:'Une erreur inconnue s\'est produite. Veuillez réessayer plus tard.';

	exit('<div class="error"><p><strong>Erreur:</strong> '.$mess.'</p>
	<p style="font-size: 0.9em; margin-left: 11px;">Cliquez <a href="./index.php"><u>ici</u></a> pour revenir à la page d\'accueil.</p></div>');
}

function move_avatar($avatar)
{
	$extension_upload = strtolower(substr(strrchr($avatar['name'], '.'), 1));
	$name = time();
	$nomavatar = str_replace(' ','',$name).".".$extension_upload;
	$name = "./avatars/".str_replace('','',$name).".".$extension_upload;
	move_uploaded_file($avatar['tmp_name'],$name);
	
		return $nomavatar;
}

function code($texte) ///mise en forme des smileys et du texte / forum
{
	//Smileys
	$texte = str_replace(':D ', '<img src="./images/smileys/heureux.gif" title="heureux" alt="heureux" />', $texte);
	
	$texte = str_replace(':lol: ', '<img src="./images/smileys/lol.gif" title="lol" alt="lol" />', $texte);
	
	$texte = str_replace(':triste:', '<img src="./images/smileys/triste.gif" title="triste" alt="triste" />', $texte);
	
	$texte = str_replace(':frime:', '<img src="./images/smileys/cool.gif" title="cool" alt="cool" />', $texte);
	
	$texte = str_replace(':rire:', '<img src="./images/smileys/rire.gif" title="rire" alt="rire" />', $texte);
	
	$texte = str_replace(':s', '<img src="./images/smileys/confus.gif" title="confus" alt="confus" />', $texte);
	
	$texte = str_replace(':O', '<img src="./images/smileys/choc.gif" title="choc" alt="choc" />', $texte);
	
	$texte = str_replace(':question:', '<img src="./images/smileys/question.gif" title="?" alt="?" />', $texte);
	
	$texte = str_replace(':exclamation:', '<img src="./images/smileys/exclamation.gif" title="!" alt="!" />', $texte);
	
	//Mise en forme du texte
	//gras
	$texte = preg_replace('`\[g\](.+)\[/g\]`isU', '<strong>$1</strong>', $texte);
	//italique
	$texte = preg_replace('`\[i\](.+)\[/i\]`isU', '<em>$1</em>', $texte);
	//souligné
	$texte = preg_replace('`\[s\](.+)\[/s\]`isU', '<u>$1</u>', $texte);
	//lien
	$texte = preg_replace('#http://[a-z0-9._/-]+#i', '<a href="$0">$0</a>', $texte);
	//etc., etc.
	
	//On retourne la variable texte
	return $texte;
}

function verif_auth($auth_necessaire)
{
	$level=(isset($_SESSION['level']))?$_SESSION['level']:1;
	return ($auth_necessaire <= intval($level));
}

function trouver_paragraphe($id){
		$req = $bdd->query('SELECT titre, contenu FROM tb_paragraphs WHERE id = :id') or die(print_r($bdd->errorInfo()));
		$query->bindValue(':id', $id, PDO::PARAM_STR);
		$query->execute();
		
		$paragraphe = $req->fetch();
	return ($paragraphe);
}
?>