<!---
Funkumo Horowitz
Page index.php
Liste tous les forums existants prévus à la base.
--->

	<?php include ('../site/includes/haut.php');?>
		
		<section><p><h2>Choisir un forum</h2></p>
		<p>Choisissez un forum où aller ; comme vous pouvez le voir, chacun des trois forums sont consacrés à un épisode de la série.<br/>
		Si vous cherchez un endroit de discussion destiné à Age of Empires II HD, dirigez-vous vers le forum du jeu originel.</p>
		
		<ul>
			<li><a href="forum_aoe/">Age of Empires</a></li>
			<li><a href="forum_aoe2/">Age of Empires II</a></li>
			<li><a href="forum_aoe3/">Age of Empires III</a></li>
		</ul>
		
		</section>
		
	<?php include ('../site/includes/footer.php'); ?>