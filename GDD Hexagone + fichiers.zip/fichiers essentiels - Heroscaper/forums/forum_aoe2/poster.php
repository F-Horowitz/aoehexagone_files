<!---
Funkumo Horowitz
Page poster.php

Page d'écriture complète permettant d'écrire et de poster des messages/sujets.
--->

	<?php
	include_once('../../motor/connexion_sql.php'); // Connexion à SQL grâce à une simple inclusion
	$balises_code = true;
		$titre = "Poster un message";  //on donne un nom à la page
		include("../../site/includes/haut.php");
		?>
		
	<div id="corps_forum">
		<section>
		<p>
		<?php //Qu'est ce qu'on veut faire ? poster, répondre ou éditer ?
			$action = (isset($_GET['action']))?htmlspecialchars($_GET['action']):'';
			
			//Il faut être connecté pour poster ! (corriger ça un peu plus tard, car pas tous les fichiers sont reliés à cause du manque de serveur)
			//if (!$connecte) erreur(ERR_IS_CO);
			
			//Si on veut poster un nouveau topic, la variable f se trouve dans l'url,
			//On récupère certaines valeurs
			if (isset($_GET['f']))
			{
				$forum = (int) $_GET['f']; //la valeur de l'id du forum actuel est récupérée dans $forum
				$query = $bdd->prepare('SELECT forum_id, forum_name, auth_view, auth_post, auth_topic,
				auth_annonce, auth_modo
				FROM forum_forum WHERE forum_id = :forum');
				$query->bindValue(':forum', $forum, PDO::PARAM_INT);
				$query->execute();
				$data = $query->fetch();
				echo '<p><i>Vous êtes ici</i> : <a href="./index.php">Index du forum</a> -->
				<a href="./voir_forum.php?f='.$data['forum_id'].'">'.stripslashes(htmlspecialchars($data['forum_name'])).'</a> --> Nouveau topic</p>';
			}
			//Sinon, c'est un nouveau message, et on possède la variable t : on récupère f grâce à une requête.
			elseif (isset($_GET['t']))
			{
				$topic = (int) $_GET['t'];
				$query=$bdd->prepare('SELECT topic_titre, forum_topic.forum_id,
				forum_name, auth_view, auth_post, auth_topic, auth_annonce, auth_modo
				FROM forum_topic
				LEFT JOIN forum_forum ON forum_forum.forum_id = forum_topic.forum_id
				WHERE topic_id = :topic');
				$query->bindValue(':topic',$topic,PDO::PARAM_INT);
				$query->execute();
				$data = $query->fetch();
				$forum = $data['forum_id'];
				echo '<p><i>Vous êtes ici</i> : <a href="./index.php">Index du forum</a> -->
				<a href="./voir_forum.php?
				f='.$data['forum_id'].'">'.stripslashes(htmlspecialchars($data['forum_name'])).'</a>
				--> <a href="./voir_sujet.php?t='.$topic.'">'.stripslashes(htmlspecialchars($data['topic_titre'])).'</a>
				--> Répondre</p>';
			}
			//Enfin sinon c'est au sujet de la modération. (on verra plus tard en détail)
			//On ne connaît que le post, il faut aller chercher le reste.
			elseif (isset ($_GET['p']))
			{
				$post = (int) $_GET['p'];
				$query = $bdd->prepare('SELECT post_createur, forum_post.topic_id, topic_titre,
				forum_topic.forum_id,
				forum_name, auth_view, auth_post, auth_topic, auth_annonce, auth_modo
				FROM forum_post
				LEFT JOIN forum_topic ON forum_topic.topic_id = forum_post.topic_id
				LEFT JOIN forum_forum ON forum_forum.forum_id = forum_topic.forum_id
				WHERE forum_post.post_id =:post');
				$query->bindValue(':post',$post,PDO::PARAM_INT);
				$query->execute();
				$data=$query->fetch();
				$topic = $data['topic_id'];
				$forum = $data['forum_id'];
				echo '<p><i>Vous êtes ici</i> : <a href="./index.php">Index du forum</a> -->
				<a href="./voir_forum.php?
				f='.$data['forum_id'].'">'.stripslashes(htmlspecialchars($data['forum_name'])).'</a>
				--> <a href="./voir_sujet.php?
				t='.$topic.'">'.stripslashes(htmlspecialchars($data['topic_titre'])).'</a> --> Modérer un message</p>';
			}
			$query->CloseCursor(); //On ferme la requête, désormais on sait pourquoi le membre est ici
			?>
			<?Php
			switch ($action)
				{
					case "repondre": //Premier cas: on souhaite répondre à un sujet!
				?>
				<h1>Poster une réponse</h1>
				<form method="post" action="post_verif.php?action=repondre&amp;t=<?php echo $topic ?>" name="formulaire">
				<?php include_once('../../motor/form_message.php'); ?></form>
				
				<?php break;
				
					case "nouveautopic":
				?>
				<h1>Nouveau topic</h1>
				<form method="post" action="post_verif.php?action=nouveautopic&amp;f=<?php echo $forum ?>" name="formulaire">
				<?php include_once('../../motor/form_message.php'); ?></form>
				
				<?php
				break;
					default: //Si jamais il y a eu un problème..
					echo('<p class="error"><strong>Erreur:</strong> Cette action est impossible</p>');
				} //Fin du switch
				?>
			</p>
		</section>
	</div>
			
	<?php include ('../../site/includes/footer.php'); ?>