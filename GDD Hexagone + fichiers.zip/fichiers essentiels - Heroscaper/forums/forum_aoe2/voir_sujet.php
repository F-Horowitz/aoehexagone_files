<!---
Funkumo Horowitz
Page voir_sujet.php

Page permettant de regarder le contenu d'un sujet.
--->

	<?php
	include_once('../../motor/connexion_sql.php'); // Connexion à SQL grâce à une simple inclusion
	$topic = 0;
	
	//On récupère la valeur de t (pour topic)
		$topic = (int) $_GET['t'];
	//A partir d'ici, on va compter le nombre de messages pour n'afficher que les 15 premiers
		$query=$bdd->prepare('SELECT topic_titre, topic_post,
		forum_topic.forum_id, topic_last_post,
		forum_name, auth_view, auth_topic, auth_post
		FROM forum_topic
		LEFT JOIN forum_forum ON forum_topic.forum_id = forum_forum.forum_id
		WHERE topic_id = :topic');
		$query->bindValue(':topic',$topic,PDO::PARAM_INT);
		$query->execute();
		$data = $query->fetch();
		
			$forum = $data['forum_id'];
		$totalDesMessages = $data['topic_post'] + 1;
		$nombreDeMessagesParPage = 15;
		$nombreDePages = ceil($totalDesMessages / $nombreDeMessagesParPage);
		?>
		
<div id="corps_forum">
		<section><?php
		echo ('<p><i>Vous êtes ici</i> : <a href="./index.php">Index du forum</a> --> <a href="./voir_forum.php?f='.$forum.'">'.stripslashes(htmlspecialchars($data['forum_name'])).'</a> --> <a href="./voir_sujet.php?t='.$topic.'">'.stripslashes(htmlspecialchars($data['topic_titre'])).'</a>');
		echo ('<h1>'.stripslashes(htmlspecialchars($data['topic_titre'])).'</h1><br/><br />');
		
		//Nombre de pages
			$page = (isset($_GET['page']))?intval($_GET['page']):1;
		//On affiche les pages 1-2-3 etc...
			echo '<p>Page : ';
			for ($i = 1 ; $i <= $nombreDePages ; $i++)
			{
				if ($i == $page) //On affiche pas la page actuelle en lien
				{
					echo $i;
				}
				else
				{
					echo '<a href="voir_sujet.php?t='.$topic.'&page='.$i.'">' . $i . '</a> ';
				}
			}
			echo('</p>');
			
		$premierMessageAafficher = ($page - 1) * $nombreDeMessagesParPage;
		
		//On affiche l'image répondre
			echo('<a href="./poster.php?action=repondre&amp;t='.$topic.'">
		<img src="./images/repondre.gif" alt="Répondre" title="Répondre à ce
		topic" /></a>');
		//On affiche l'image nouveau topic
			echo('<a href="./poster.php?action=nouveautopic&amp;f='.$data['forum_id'].'"><img src="./images/nouveau.gif" alt="Nouveau topic" title="Nouveau topic" /></a>');
		$query->CloseCursor();
		
		//Enfin on commence la boucle !
		$query=$bdd->prepare('SELECT post_id , post_createur , post_texte , post_time ,
		membre_id, membre_pseudo, membre_inscrit, membre_avatar,
		membre_localisation, membre_post, membre_signature
		FROM forum_post
		LEFT JOIN forum_membres ON forum_membres.membre_id = forum_post.post_createur
		WHERE topic_id =:topic
		ORDER BY post_id
		LIMIT :premier, :nombre');
		$query->bindValue(':topic',$topic,PDO::PARAM_INT);
		$query->bindValue(':premier',(int)
		$premierMessageAafficher,PDO::PARAM_INT);
		$query->bindValue(':nombre',(int)
		$nombreDeMessagesParPage,PDO::PARAM_INT);
		
		$query->execute();
		//On vérifie que la requête a bien retourné des messages
		if ($query->rowCount()<1)
		{
			echo'<p>Il n\'y a aucun post sur ce topic. Si vous pensez vous êtes trompé de sujet, vérifiez l\'URL.</p>';
		}
		else
		{
			//Si tout roule on affiche notre tableau puis on remplit avec une boucle
		?>
		<table>
			<tr>
			<th class="vt_auteur"><strong>Auteurs</strong></th>
			<th class="vt_mess"><strong>Messages</strong></th>
			</tr>
		<?php
		while ($data = $query->fetch())
		{
			//On commence à afficher le pseudo du créateur du message : on vérifie les droits du membre
			//(partie du code commentée plus tard)
			echo'<tr><td><strong>
			<a href="./voir_profil.php?m='.$data['membre_id'].'&amp;action=consulter">
			'.stripslashes(htmlspecialchars($data['membre_pseudo'])).'</a></strong></td>';
			/* Si on est l'auteur du message, on affiche des liens pour modérer celui-ci.
			Les modérateurs pourront aussi le faire, il faudra donc revenir sur	ce code un peu plus tard ! */
			
			if ($id == $data['post_createur'])
			{
				echo'<td id=p_'.$data['post_id'].'>Posté à '.date('H\hi \l\e d M y',$data['post_time']).'
				<a href="./poster.php?p='.$data['post_id'].'&amp;action=supprimer">
				<img src="./images/supprimer.gif" alt="Supprimer" title="Supprimer ce message" /></a>
				<a href="./poster.php?p='.$data['post_id'].'&amp;action=editer">
				<img src="./images/editer.gif" alt="Editer" title="Editer ce message" /></a>
				</td></tr>';
			}
			else
			{
				echo'<td>Posté à '.date('H\hi \l\e d M y',$data['post_time']).'</td></tr>';
			}
			
			//Détails sur le membre qui a posté ce message..
			echo('<tr><td>
			<img src="../../avatars/'.$data['membre_avatar'].'" alt="" />
			<br /><em>Inscrit depuis le '.date('d/m/Y',$data['membre_inscrit']).'</em>
			<br />Messages : '.$data['membre_post'].'<br />');
			
			// On affiche enfin le message !
			echo('<td>'.code(nl2br(stripslashes(htmlspecialchars($data['post_texte'])))).'<br /><hr/>' . code(nl2br(stripslashes(htmlspecialchars($data['membre_signature'])))) . '</td></tr>');
		}
		//La boucle est terminée, normalement tous les messages sont affichées.
		
			$query->CloseCursor();
			?>
			</table>

		?>
		
			<table>
				<tr>
				<th><img src="./images/annonce.png" alt="Annonce" /></th>
				<th class="titre"><strong>Titre</strong></th>
				<th class="nombremessages"><strong>Réponses</strong></th>
				<th class="nombrevu"><strong>Vues</strong></th>
				<th class="auteur"><strong>Auteur</strong></th>
				<th class="derniermessage"><strong>Dernier message posté</strong></th>
				</tr>
			<?php
			//On commence la boucle
			while ($data=$query->fetch())
			{
				//Pour chaque topic : si le topic est une annonce on l'affiche en haut
				
				echo'<tr><td><img src="./images/annonce.png" alt="Annonce"
				/></td>
				<td id="titre"><strong>Annonce : </strong>
				<strong><a href="./voir_sujet.php?t='.$data['topic_id'].'"
				title="Topic commencé à	' . date('H\hi \l\e d M,y',$data['topic_time']).'"> ' . stripslashes(htmlspecialchars($data['topic_titre'])) . '</a></strong></td>
				<td class="nombremessages">'.$data['topic_post'].'</td>
				<td class="nombrevu">'.$data['topic_vu'].'</td>
				<td><a href="./voir_profil.php?m='.$data['topic_createur'].'	&amp;action=consulter">'.stripslashes(htmlspecialchars($data['membre_pseudo_createur'])).'</a></td>';
				
				//Sélection des derniers messages
				
				$nombreDeMessagesParPage = 15;
				$nbr_post = $data['topic_post'] +1;
				$page = ceil($nbr_post / $nombreDeMessagesParPage);
				echo '<td class="derniermessage">Par
				<a href="./voir_profil.php?m='.$data['post_createur'].'
				&amp;action=consulter">'.stripslashes(htmlspecialchars($data['membre_pseudo_last_posteur'])).'</a><br/>
				à <a href="./voir_sujet.php?t='.$data['topic_id'].'&amp;page='.$page.'#p_'.$data['post_id'].'">'.date('H\hi\l\e d M y',$data['post_time']).'</a></td></tr>';
			}
			?>
			</table>
			<?php
			}
			$query->CloseCursor();
			?>
			
			<?php
			//On prend tout ce qu'on a sur les topics normaux du forum!
			$query=$bdd->prepare('SELECT forum_topic.topic_id, topic_titre, topic_createur,
			topic_vu, topic_post, topic_time, topic_last_post,
			Mb.membre_pseudo AS membre_pseudo_createur, post_id, post_createur, post_time,
			Ma.membre_pseudo AS membre_pseudo_last_posteur FROM forum_topic
			LEFT JOIN forum_membres Mb ON Mb.membre_id = forum_topic.topic_createur
			LEFT JOIN forum_post ON forum_topic.topic_last_post = forum_post.post_id
			LEFT JOIN forum_membres Ma ON Ma.membre_id = forum_post.post_createur
			WHERE topic_genre <> "Annonce" AND forum_topic.forum_id = :forum
			ORDER BY topic_last_post DESC
			LIMIT :premier ,:nombre');
			$query->bindValue(':forum',$forum,PDO::PARAM_INT);
			$query->bindValue(':premier',(int) $premierMessageAafficher,PDO::PARAM_INT);
			$query->bindValue(':nombre',(int) $nombreDeMessagesParPage,PDO::PARAM_INT);
			$query->execute();
			
			if ($query->rowCount()>0)
			{ ?>
			<table>
				<tr>
				<th><img src="./images/message.gif" alt="Message" /></th>
				<th class="titre"><strong>Titre</strong></th>
				<th class="nombremessages"><strong>Réponses</strong></th>
				<th class="nombrevu"><strong>Vues</strong></th>
				<th class="auteur"><strong>Auteur</strong></th>
				<th class="derniermessage"><strong>Dernier message posté</strong></th>
				</tr>
			<?php
			//On lance la boucle
				while ($data = $query->fetch())
				{
					//Ah bah tiens... re voilà l'echo de fou
					echo'<tr><td><img src="./images/message.gif" alt="Message"/></td>
					<td class="titre"><strong><a href="./voir_sujet.php?t='.$data['topic_id'].'"title="Topic commencé à '.date('H\hi \l\e d M,y',$data['topic_time']).'">
					'.stripslashes(htmlspecialchars($data['topic_titre'])).'</a></strong></td>
					<td class="nombremessages">'.$data['topic_post'].'</td>
					<td class="nombrevu">'.$data['topic_vu'].'</td>
					<td><a href="./voir_profil.php?m='.$data['topic_createur'].'
					&amp;action=consulter">
					'.stripslashes(htmlspecialchars($data['membre_pseudo_createur'])).'</a></td>';
					
					//Sélection des derniers messages
					$nombreDeMessagesParPage = 15;
					$nbr_post = $data['topic_post'] +1;
					$page = ceil($nbr_post / $nombreDeMessagesParPage);
					echo '<td class="derniermessage">Par <a href="./voir_profil.php?m='.$data['post_createur'].'&amp;action=consulter">'.stripslashes(htmlspecialchars($data['membre_pseudo_last_posteur'])).'</a><br/>
					à <a href="./voir_sujet.php?t='.$data['topic_id'].'&amp;page='.$page.'#p_'.$data['post_id'].'">'.date('H\hi
					\l\e d M y',$data['post_time']).'</a></td></tr>';
				}
			?>
			</table>
			
			<?php
			}
			else //S'il n'y a pas de message..
			{
				echo'<p>Ce forum ne contient </em>aucun sujet</em> actuellement.</p>';
			}
			
			$query->CloseCursor();
			?>
			</p>
		</section>
			
	<?php include ('../../site/includes/footer.php'); ?>