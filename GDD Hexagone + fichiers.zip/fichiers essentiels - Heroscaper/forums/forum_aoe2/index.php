﻿<!---
Funkumo Horowitz
Page index.php

Page d'accueil du forum Age of Empires II.
--->

	<?php
	include_once('../../motor/connexion_sql.php'); // Connexion à SQL grâce à une simple inclusion
	include('../../site/includes/haut.php');
		$titre = "Index du forum";  //on donne un nom à la page
		
		
		//Initialisation de deux variables pour limiter le nombre de requêtes
		$total_messages = 0;
		$categorie = NULL;
		$lvl = ADMIN;
		$dernier_membre = NULL;
		
		?>
	<div id="corps_forum">
		<section>
		<?php echo('<i>Vous êtes ici : </i><a href ="index.php">Index du forum</a>');
		
			///AFFICHAGE DE CATÉGORIES
			//Cette requête permet d'obtenir tout sur le forum
				$query = $bdd->prepare('SELECT cat_id, cat_nom, forum_forum.forum_id, forum_name, forum_desc, forum_post,
				forum_topic, auth_view, forum_topic.topic_id, forum_topic.topic_post, post_id, post_time, post_createur,
				membre_pseudo, membre_id FROM forum_categorie
				LEFT JOIN forum_forum ON forum_categorie.cat_id = forum_forum.forum_cat_id
				LEFT JOIN forum_post ON forum_post.post_id = forum_forum.forum_last_post_id
				LEFT JOIN forum_topic ON forum_topic.topic_id = forum_post.topic_id
				LEFT JOIN forum_membres ON forum_membres.membre_id = forum_post.post_createur
				WHERE auth_view <= :lvl
				ORDER BY cat_ordre, forum_ordre DESC');
				$query->execute(array(':lvl' => $lvl));
				$data = $query->fetch(); ?>
				
				<table>
					<h2>Forum <?php echo stripslashes(htmlspecialchars($data['cat_nom'])); ?></h2>
						<tr>
						<th></th>
						<th class="titre"><strong style="font-family: 'Lucida Blackletter', sans-serif;">Catégorie</strong></th>
						<th class="nombre_messages"><strong>Sujets</strong></th>
						<th class="nombre_sujets"><strong>Messages</strong></th>
						<th class="dernier_message"><strong>Dernier message envoyé</strong></th>
						</tr>
					<?php
					
					//Ici, on met le contenu de chaque catégorie
				
			// Ce super echo de la mort affiche tous les forums en détail : description, nombre de réponses etc...
			echo('<tr><td class="icone_message"><img src="../../images/message.png" alt="message" /></td>
			<td class="titre"><strong><a href="./voir_forum.php?f='.$data['forum_id'].'">'.stripslashes(htmlspecialchars($data['forum_name'])).'</a></strong><br />
			<div class="forum_description">'.nl2br(stripslashes(htmlspecialchars($data['forum_desc']))).'</div></td>
			<td class="nombre_sujets">'.$data['forum_topic'].'</td>
			<td class="nombre_messages">'.$data['forum_post'].'</td>');
			// Deux cas possibles :
			// Soit il y a un nouveau message, soit le forum est vide
				if (!empty($data['forum_post']))
				{
					//Sélection dernier message
					$nombreDeMessagesParPage = 15;
					$nbr_post = $data['topic_post'] +1;
					$page = ceil($nbr_post / $nombreDeMessagesParPage); ?>
					<td class="dernier_message"><?php echo date('H\hi \l\e d/M/Y',$data['post_time']) ?> <br /><a href="./voir_profil.php?m=<?php echo stripslashes(htmlspecialchars($data['membre_id'])); ?>&amp;action=consulter"></a><a href="./voir_sujet.php?t=<?php echo $data['topic_id'] ?> &amp;page="<?php echo $page.'#p_'.$data['post_id']?>"><img src="./images/go.gif" alt="go"/></a></td></tr>
				<?php
				}
				else
				{
					echo'<td class="nombre_messages" style="font-size: 0.9em;">Aucun message..</td></tr>';
				}
					
					//Cette variable stocke le nombre de messages, on la met à jour
					$total_messages += $data['forum_post'];

					//On ferme nos balises
					echo '</table>';
				?>
		<div id="footer_forum">
				<?php ///PIED DE PAGE (FOOTER)
				
					echo('<p><i id="qui_est_en_ligne">Qui est en ligne ?</i>');
					
					//créer système pour savoir qui est en ligne
					
					
					echo('</p>'); //fin de la ligne "qui est en ligne"
					echo('<p>Le total de messages postés sur le forum Age of Empires II est	de <strong>'.$total_messages.'</strong>.<br /></p>');				
				 ?>
			
		</section></div>
			
	<?php include ('../../site/includes/footer.php'); ?>