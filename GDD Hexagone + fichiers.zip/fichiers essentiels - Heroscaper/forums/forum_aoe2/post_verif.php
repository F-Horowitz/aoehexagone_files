<!---
Funkumo Horowitz
Page post_verif.php

Page d'écriture complète permettant d'écrire et de poster des messages/sujets.
--->

	<?php
	include_once('../../motor/connexion_sql.php'); // Connexion à SQL grâce à une simple inclusion
		$titre = "Poster un message";  //on donne un nom à la page
		include("../../site/includes/haut.php");
		?>
		
	<div id="corps_forum">
		<section>
		<p>
		<?php //Qu'est ce qu'on veut faire ? poster, répondre ou éditer ?
			$action = (isset($_GET['action']))?htmlspecialchars($_GET['action']):'';
			$id = 0;
			$mess = 0;			
			
			//Il faut être connecté pour poster !
			//if (!$connecte) erreur(ERR_IS_CO); réactiver quand tout sera bon niveau liaison de pages
			
			switch($action)
			{
					//Premier cas : nouveau sujet
					case "nouveautopic":
				//On passe le message dans une série de fonction
				$message = $_POST['message'];
				//Pareil pour le titre
				$titre = $_POST['titre'];
				//ici seulement, maintenant qu'on est sur qu'elle existe, on récupère la valeur de la variable f
				$forum = (int) $_GET['f'];
				$temps = time();
				if (empty($message) || empty($titre))
				{
					echo'<p>Votre message ou titre de sujet est vide.<br/>
					Cliquez <a href="./poster.php?action=nouveautopic&amp;f='.$forum.'">ici</a> pour recommencer.</p>';
				}
				else //Si jamais le message n'est pas vide
				{
					//On entre le topic dans la base de donnée en laissant le champ topic_last_post à 0
					$query=$bdd->prepare('INSERT INTO forum_topic(forum_id, topic_titre, topic_createur, topic_vu, topic_time,
					topic_genre) VALUES(:forum, :titre, :id, 1, :temps, :mess)');
					$query->bindValue(':forum', $forum, PDO::PARAM_INT);
					$query->bindValue(':titre', $titre, PDO::PARAM_STR);
					$query->bindValue(':id', $id, PDO::PARAM_INT);
					$query->bindValue(':temps', $temps, PDO::PARAM_INT);
					$query->bindValue(':mess', $mess, PDO::PARAM_STR);
					$query->execute();
					
					$nouveautopic = $bdd->lastInsertId(); //Notre fameuse fonction !
					$query->CloseCursor();
					
					//Puis on entre le message
					$query=$bdd->prepare('INSERT INTO forum_post
					(post_createur, post_texte, post_time, topic_id, post_forum_id)
					VALUES (:id, :mess, :temps, :nouveautopic, :forum)');
					$query->bindValue(':id', $id, PDO::PARAM_INT);
					$query->bindValue(':mess', $message, PDO::PARAM_STR);
					$query->bindValue(':temps', $temps,PDO::PARAM_INT);
					$query->bindValue(':nouveautopic', (int) $nouveautopic,
					PDO::PARAM_INT);
					$query->bindValue(':forum', $forum, PDO::PARAM_INT);
					$query->execute();
					$nouveaupost = $bdd->lastInsertId(); //Encore notre fameuse fonction !
					
					$query->CloseCursor();
					
					//Ici on update comme prévu la valeur de topic_last_post et	de topic_first_post
					$query=$bdd->prepare('UPDATE forum_topic
					SET topic_last_post = :nouveaupost,
					topic_first_post = :nouveaupost
					WHERE topic_id = :nouveautopic');
					$query->bindValue(':nouveaupost', (int) $nouveaupost,
					PDO::PARAM_INT);
					$query->bindValue(':nouveautopic', (int) $nouveautopic,
					PDO::PARAM_INT);
					$query->execute();
					$query->CloseCursor();
					
					//Enfin on met à jour les tables forum_forum et	forum_membres
					$query=$bdd->prepare('UPDATE forum_forum SET forum_post =
					forum_post + 1 ,forum_topic = forum_topic + 1,
					forum_last_post_id = :nouveaupost
					WHERE forum_id = :forum');
					$query->bindValue(':nouveaupost', (int) $nouveaupost,
					PDO::PARAM_INT);
					$query->bindValue(':forum', (int) $forum, PDO::PARAM_INT);
					$query->execute();
					
					$query->CloseCursor();//on ferme la requête
					
					$query=$bdd->prepare('UPDATE forum_membres SET membre_post =
					membre_post + 1 WHERE membre_id = :id');
					$query->bindValue(':id', $id, PDO::PARAM_INT);
					$query->execute();
					$query->CloseCursor();
					
					//Et un petit message pour dire que tout s'est bien passé..
					echo('<p>Votre message a bien été posté.<br /><br />
					Cliquez	<a href="./index.php">ici</a> pour revenir à la page d\'accueil du forum.<br />
					ou alors <a href="./voir_sujet.php?t='.$nouveautopic.'">ici</a> pour le voir.</p>');
				}
					break; //Hourra !
					
						case "repondre": //Deuxième cas : répondre
					$message = $_POST['message'];
					//ici seulement, maintenant qu'on est sur qu'elle existe, on récupère la valeur de la variable "t"
					$topic = (int) $_GET['t'];
					$temps = time();
					
					if (empty($message))
					{
						echo'<p class="error">Votre message est vide.<br/>Cliquez <a href="./poster.php?action=repondre&amp;t='.$topic.'">ici</a> pour recommencer.</p>';
					}
					else //Sinon, si le message n'est pas vide..
					{
						//On récupère l'id du forum
						$query=$bdd->prepare('SELECT forum_id, topic_post FROM
						forum_topic WHERE topic_id = :topic');
						$query->bindValue(':topic', $topic, PDO::PARAM_INT);
						$query->execute();
						$data=$query->fetch();
						$forum = $data['forum_id'];
						//Puis on entre le message
						$query=$bdd->prepare('INSERT INTO forum_post
						(post_createur, post_texte, post_time, topic_id, post_forum_id)
						VALUES(:id,:mess,:temps,:topic,:forum)');
						$query->bindValue(':id', $id, PDO::PARAM_INT);
						$query->bindValue(':mess', $message, PDO::PARAM_STR);
						$query->bindValue(':temps', $temps, PDO::PARAM_INT);
						$query->bindValue(':topic', $topic, PDO::PARAM_INT);
						$query->bindValue(':forum', $forum, PDO::PARAM_INT);
						$query->execute();
						$nouveaupost = $db->lastInsertId();
						$query->CloseCursor();
						//On change un peu la table forum_topic
						$query=$bdd->prepare('UPDATE forum_topic SET topic_post =
						topic_post + 1, topic_last_post = :nouveaupost WHERE topic_id
						=:topic');
						$query->bindValue(':nouveaupost', (int) $nouveaupost,
						PDO::PARAM_INT);
						$query->bindValue(':topic', (int) $topic, PDO::PARAM_INT);
						$query->execute();
						$query->CloseCursor();
						
						//Puis même combat sur les 2 autres tables
						$query=$bdd->prepare('UPDATE forum_forum SET forum_post =
						forum_post + 1 , forum_last_post_id = :nouveaupost WHERE forum_id =
						:forum');
						$query->bindValue(':nouveaupost', (int) $nouveaupost,
						PDO::PARAM_INT);
						$query->bindValue(':forum', (int) $forum, PDO::PARAM_INT);
						$query->execute();
						$query->CloseCursor();
						$query=$db->prepare('UPDATE forum_membres SET membre_post =
						membre_post + 1 WHERE membre_id = :id');
						$query->bindValue(':id', $id, PDO::PARAM_INT);
						$query->execute();
						$query->CloseCursor();
						
						//Et un petit message..
						$nombreDeMessagesParPage = 15;
						$nbr_post = $data['topic_post']+1;
						$page = ceil($nbr_post / $nombreDeMessagesParPage);
						echo'<p>Votre message a bien été posté!<br /><br />
						Cliquez <a href="./index.php">ici</a> pour revenir à la page d\'accueil du forum ou<br />
						cliquez <a href="./voir_sujet.php?t='.$topic.'&amp;page='.$page.'#p_'.$nouveaupost.'">ici</a> pour le
						voir.</p>';
					
					}//Fin du else
					break;
				
						case "repondre_mp": //Si on veut répondre
					//On récupère le titre et le message
					$message = $_POST['message'];
					$titre = $_POST['titre'];
					$temps = time();
					//On récupère la valeur de l'id du destinataire
					$dest = (int) $_GET['dest'];
					//Enfin on peut envoyer le message
					$query=$bdd->prepare('INSERT INTO forum_mp
					(mp_expediteur, mp_receveur, mp_titre, mp_text, mp_time, mp_lu)
					VALUES(:id, :dest, :titre, :txt, :tps, 0)');
					
					$query->bindValue(':id',$id,PDO::PARAM_INT);
					$query->bindValue(':dest',$dest,PDO::PARAM_INT);
					$query->bindValue(':titre',$titre,PDO::PARAM_STR);
					$query->bindValue(':txt',$message,PDO::PARAM_STR);
					$query->bindValue(':tps',$temps,PDO::PARAM_INT);
					$query->execute();
					$query->CloseCursor();
					
					echo('<p>Votre message a bien été envoyé!<br />
					<br />Cliquez <a href="./index.php">ici</a> pour revenir à l\'index du forum.<br />
					<br />Cliquez <a href="./boite_mp.php">ici</a> pour retourner
					à la messagerie.</p>');
					break;
					
						case "nouveau_mp": //On envoie un nouveau mp
					//On récupère le titre et le message
					$message = $_POST['message'];
					$titre = $_POST['titre'];
					$temps = time();
					$dest = $_POST['to'];
					//On récupère la valeur de l'id du destinataire
					//Il faut déja vérifier le nom
					$query=$bdd->prepare('SELECT membre_id FROM forum_membres
					WHERE LOWER(membre_pseudo) = :dest');
					$query->bindValue(':dest',strtolower($dest),PDO::PARAM_STR);
					$query->execute();
					
					if ($data = $query->fetch())
					{
						$query=$bdd->prepare('INSERT INTO forum_mp
						(mp_expediteur, mp_receveur, mp_titre, mp_text, mp_time, mp_lu)
						VALUES(:id, :dest, :titre, :txt, :tps, :lu)');
						$query->bindValue(':id',$id,PDO::PARAM_INT);
						$query->bindValue(':dest',(int)
						$data['membre_id'],PDO::PARAM_INT);
						$query->bindValue(':titre',$titre,PDO::PARAM_STR);
						$query->bindValue(':txt',$message,PDO::PARAM_STR);
						$query->bindValue(':tps',$temps,PDO::PARAM_INT);
						$query->bindValue(':lu','0',PDO::PARAM_STR);
						$query->execute();
						$query->CloseCursor();
					echo'<p>Votre message a bien été envoyé!
					<br /><br />Cliquez <a href="./index.php">ici</a> pour revenir à l\'index du forum.<br />
					<br />Cliquez <a href="./boite_mp.php">ici</a> pour retourner	à la messagerie.</p>';
					}
					//Sinon... l'utilisateur n'existe pas !
					else
					{
						echo'<p>Désolé ce membre n\'existe pas, veuillez vérifier et réessayez à nouveau.</p>';
					}
					
					default;
					echo('<p class="error"><strong>Erreur:</strong> Cette action est impossible</p>');
				}
				//Fin du switch
					?>
			</p>
		</section>
	</div>
			
	<?php include ('../../site/includes/footer.php'); ?>